transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vcom -93 -work work {C:/Users/dda/DAW_ecse222_lab/lab1/xnor_gate.vhd}

vcom -93 -work work {C:/Users/dda/DAW_ecse222_lab/lab1/test_xnor_gate.vhd}

vsim -t 1ps -L altera -L lpm -L sgate -L altera_mf -L altera_lnsim -L cyclonev -L rtl_work -L work -voptargs="+acc"  testbench2

add wave *
view structure
view signals
run -all
