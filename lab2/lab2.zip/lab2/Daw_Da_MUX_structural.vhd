library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Daw_Da_MUX_structural is
    Port ( A : in std_logic;
           B : in std_logic;
           S : in std_logic;
           Y : out std_logic);
end Daw_Da_MUX_structural;

architecture Structural of Daw_Da_MUX_structural is
begin
    -- Realizing the boolean function using AND, OR, and NOT gates
    Y <= (A and not S) or (B and S);
end Structural;